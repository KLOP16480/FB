# bot-facebook

สอนใช้BOTใน PC/Linux/termux
____________________________
1.หาappstate.json แล้วเอามาใส่ในไฟล์
วิธีหา
>https://youtu.be/q6F70f0Pgjc
____________________________
[สำหรับPC/linux]

2.รัน node bot.js 

3.command bot "!help"
____________________________
[สำหรับtermux]
1. หาappstate.json แล้วเอามาใส่ในไฟล์
2. pkg install nodejs
3. unzip node_modules.zip (แตกไฟล์node_modules.zip)
4. รัน node bot.js
____________________________
